UPDATE mailmessages SET frommailbox = NULL;

