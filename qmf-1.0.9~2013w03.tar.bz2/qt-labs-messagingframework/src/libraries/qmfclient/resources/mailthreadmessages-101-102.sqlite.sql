INSERT INTO mailmessages(threadid) FROM (SELECT id mailthreadmessages)


DROP TABLE mailthreadmessages("messageid");
