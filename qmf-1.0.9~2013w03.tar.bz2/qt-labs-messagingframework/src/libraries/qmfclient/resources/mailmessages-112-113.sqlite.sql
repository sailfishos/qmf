ALTER TABLE mailmessages ADD COLUMN latestinconversation INTEGER;
