ALTER TABLE mailmessages ADD COLUMN receivedstamp TIMESTAMP;
