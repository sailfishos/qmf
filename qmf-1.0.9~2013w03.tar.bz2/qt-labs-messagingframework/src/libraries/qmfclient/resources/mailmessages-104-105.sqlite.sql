UPDATE mailstatusflags SET name = 'ContentAvailable' WHERE name = 'Downloaded' AND context = 'messagestatus';
