CREATE TABLE maintenancerecord ( 
    task VARCHAR,
    performed TIMESTAMP NOT NULL);
